I am using python 2.7
run this command to get the output:
	python viterbi.py probs.txt sents.txt
I have tested the code on CADE lab l25 machine
Though please make sure the paths are correct and all the required files are in the required path.
Thanks

